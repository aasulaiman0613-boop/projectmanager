import "./globals.css";
import { ReactNode } from "react";
import Sidebar from "../components/sidebar";
import Header from "../components/header";
import { Providers } from "../components/providers";

export const metadata = {
  title: "PlugManager Web",
  description: "PlugManager Web - dashboard"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <div className="min-h-screen flex bg-slate-50 dark:bg-slate-900">
            <Sidebar />
            <div className="flex-1 min-h-screen flex flex-col">
              <Header />
              <main className="p-6 container">{children}</main>
            </div>
          </div>
        </Providers>
      </body>
    </html>
  );
}