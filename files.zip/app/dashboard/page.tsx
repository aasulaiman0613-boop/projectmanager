import Card from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { useEffect } from "react";

const DemoCard = ({ title, value }: { title: string; value: string }) => (
  <Card>
    <div className="flex items-center justify-between">
      <div>
        <div className="text-sm text-muted">{title}</div>
        <div className="text-2xl font-semibold">{value}</div>
      </div>
      <div>
        <Button size="sm">View</Button>
      </div>
    </div>
  </Card>
);

export default function DashboardPage() {
  useEffect(() => {
    // placeholder side effect
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <DemoCard title="Active Packs" value="1,234" />
        <DemoCard title="Inventory Items" value="5,420" />
        <DemoCard title="Sales (30d)" value="$42,300" />
        <DemoCard title="Promoters" value="27" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <h2 className="text-lg font-medium mb-4">Recent Sales</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-muted">
                  <th className="pb-2">Order</th>
                  <th className="pb-2">Customer</th>
                  <th className="pb-2">Amount</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-2">#1001</td>
                  <td className="py-2">Alice</td>
                  <td className="py-2">$120</td>
                  <td className="py-2">Paid</td>
                </tr>
                <tr className="border-t">
                  <td className="py-2">#1000</td>
                  <td className="py-2">Bob</td>
                  <td className="py-2">$60</td>
                  <td className="py-2">Pending</td>
                </tr>
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <h2 className="text-lg font-medium mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Button>New Pack</Button>
            <Button variant="outline">Add Inventory</Button>
            <Button variant="ghost">Export CSV</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}