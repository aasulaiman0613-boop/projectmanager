import Card from "../../components/ui/card";

export default function DropsPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Drops</h1>
      <Card>
        <div className="text-sm">Drop scheduler and list placeholder</div>
      </Card>
    </div>
  );
}