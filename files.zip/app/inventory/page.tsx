import Card from "../../components/ui/card";
import { useEffect, useState } from "react";
import { db } from "../../lib/db";
import { Button } from "../../components/ui/button";

export default function InventoryPage() {
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    let mounted = true;
    db.inventoryBatches.toArray().then((rows) => {
      if (!mounted) return;
      setItems(rows);
    });
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Inventory</h1>
      <div className="flex justify-between mb-4">
        <div className="text-sm text-muted">Manage purchase batches and stock</div>
        <div className="flex gap-2">
          <Button variant="outline">Import CSV</Button>
          <Button>New Batch</Button>
        </div>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase text-muted">
                <th className="pb-2">SKU / Item</th>
                <th className="pb-2">Units</th>
                <th className="pb-2">Cost</th>
                <th className="pb-2">Supplier</th>
                <th className="pb-2">Date</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="py-2">{r.itemName ?? r.sku}</td>
                  <td className="py-2">{r.units}</td>
                  <td className="py-2">${r.cost}</td>
                  <td className="py-2">{r.supplier}</td>
                  <td className="py-2">{new Date(r.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}

              {items.length === 0 && (
                <tr>
                  <td className="py-8 text-center" colSpan={5}>
                    No batches yet — add one to begin.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}