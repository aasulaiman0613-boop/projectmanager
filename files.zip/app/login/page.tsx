"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { setupInitialUser, login as authLogin } from "../../lib/auth";
import { Button } from "../../components/ui/button";
import Card from "../../components/ui/card";
import { Input } from "../../components/ui/input";

export default function LoginPage() {
  const router = useRouter();
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // ensure initial seed user exists
    setupInitialUser().catch((e) => {
      // ignore
      console.error(e);
    });
  }, []);

  async function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault();
    setLoading(true);
    try {
      const ok = await authLogin(pin);
      if (ok) {
        router.push("/dashboard");
      } else {
        alert("Invalid PIN");
      }
    } catch (err) {
      console.error(err);
      alert("Login error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Card>
        <h1 className="text-xl font-semibold mb-4">PlugManager Login</h1>
        <form onSubmit={handleSubmit} className="space-y-4 w-80">
          <Input
            label="PIN / Password"
            value={pin}
            onChange={(v) => setPin(v.target.value)}
            placeholder="Enter your PIN"
            type="password"
          />
          <div className="flex justify-between items-center">
            <Button onClick={handleSubmit} disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
            </Button>
            <Button variant="ghost" onClick={() => { setPin("1234"); }}>
              Demo PIN
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}