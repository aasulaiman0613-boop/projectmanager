import Card from "../../components/ui/card";

export default function ReportsPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Reports</h1>
      <Card>
        <div className="text-sm">Filters and export UI placeholder</div>
      </Card>
    </div>
  );
}