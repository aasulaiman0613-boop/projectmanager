import Card from "../../components/ui/card";

export default function MessagesPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Messages</h1>
      <Card>
        <div className="text-sm">Local-only threads with promoters</div>
      </Card>
    </div>
  );
}