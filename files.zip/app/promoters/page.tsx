import Card from "../../components/ui/card";
import { useEffect, useState } from "react";
import { db } from "../../lib/db";
import { Button } from "../../components/ui/button";

export default function PromotersPage() {
  const [promoters, setPromoters] = useState<any[]>([]);

  useEffect(() => {
    db.promoters.toArray().then(setPromoters);
  }, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Promoters</h1>
        <Button>New Promoter</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {promoters.map((p) => (
          <Card key={p.id}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted">Promoter</div>
                <div className="font-semibold">{p.name}</div>
              </div>
              <Button size="sm" variant="outline">
                Pay
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}