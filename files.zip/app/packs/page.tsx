import Card from "../../components/ui/card";
import { useEffect, useState } from "react";
import { db } from "../../lib/db";
import { Button } from "../../components/ui/button";

export default function PacksPage() {
  const [packs, setPacks] = useState<any[]>([]);

  useEffect(() => {
    db.packTemplates.toArray().then(setPacks);
  }, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Packs</h1>
        <div>
          <Button>New Pack</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {packs.map((p) => (
          <Card key={p.id}>
            <div className="flex items-start justify-between">
              <div>
                <div className="text-sm text-muted">Pack</div>
                <div className="font-semibold text-lg">{p.name}</div>
                <div className="text-sm text-muted">Units: {p.units_required}</div>
              </div>
              <div className="flex flex-col gap-2">
                <Button size="sm">Edit</Button>
                <Button variant="outline" size="sm">
                  Duplicate
                </Button>
              </div>
            </div>
          </Card>
        ))}
        {packs.length === 0 && (
          <Card>
            <div>No packs found</div>
          </Card>
        )}
      </div>
    </div>
  );
}