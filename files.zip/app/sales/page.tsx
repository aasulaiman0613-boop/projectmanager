import Card from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { useState } from "react";

export default function SalesPage() {
  const [openQuick, setOpenQuick] = useState(false);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Sales</h1>
        <div>
          <Button onClick={() => setOpenQuick(true)}>Quick Sale (Q)</Button>
        </div>
      </div>

      <Card>
        <div className="text-muted mb-2">Recent sales and actions</div>
        <div className="text-sm">Placeholder list of sales will render here.</div>
      </Card>
    </div>
  );
}