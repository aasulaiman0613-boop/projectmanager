import Card from "../../components/ui/card";

export default function AuditPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Audit Log</h1>
      <Card>
        <div className="text-sm">Append-only logs are shown here</div>
      </Card>
    </div>
  );
}