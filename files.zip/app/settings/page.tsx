import Card from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { useRouter } from "next/navigation";

export default function SettingsPage() {
  const router = useRouter();
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <div>
          <Button variant="outline" onClick={() => router.push("/login")}>
            Lock Now
          </Button>
        </div>
      </div>

      <Card>
        <h2 className="text-lg font-medium mb-2">Profile & Security</h2>
        <div className="text-sm text-muted">Manage PIN, encryption and profiles</div>
        <div className="mt-4 flex gap-2">
          <Button>Change PIN</Button>
          <Button variant="destructive">Wipe All Data</Button>
        </div>
      </Card>
    </div>
  );
}