"use client";
import React from "react";

export function Input({ label, value, onChange, placeholder, type = "text" }: { label?: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return (
    <label className="block">
      {label && <div className="text-sm mb-1">{label}</div>}
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} type={type} className="w-full px-3 py-2 border rounded-md dark:bg-slate-700" />
    </label>
  );
}