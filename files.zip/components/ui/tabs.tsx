"use client";
import React from "react";

export function Tabs({ tabs, active, onChange }: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div className="flex gap-2">
      {tabs.map((t) => (
        <button key={t} onClick={() => onChange(t)} className={`px-3 py-1 rounded ${active === t ? "bg-slate-100 dark:bg-slate-700" : "hover:bg-slate-50 dark:hover:bg-slate-700"}`}>
          {t}
        </button>
      ))}
    </div>
  );
}