"use client";
import React from "react";
import clsx from "clsx";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "outline" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg";
};

export const Button = ({ className, variant = "default", size = "md", children, ...props }: ButtonProps) => {
  const base = "inline-flex items-center justify-center rounded-md font-medium transition-colors";
  const sizes: Record<string, string> = {
    sm: "px-2 py-1 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2"
  };
  const variants: Record<string, string> = {
    default: "bg-slate-900 text-white hover:bg-slate-800",
    outline: "border border-slate-200 dark:border-slate-700",
    ghost: "bg-transparent hover:bg-slate-100 dark:hover:bg-slate-700",
    destructive: "bg-red-600 text-white hover:bg-red-700"
  };
  return (
    <button className={clsx(base, sizes[size], variants[variant], className)} {...props}>
      {children}
    </button>
  );
};

export default Button;