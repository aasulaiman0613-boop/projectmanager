import React from "react";

const Card = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => {
  return (
    <div className={"bg-white dark:bg-slate-800 border rounded-md p-4 shadow-sm " + className}>
      {children}
    </div>
  );
};

export default Card;