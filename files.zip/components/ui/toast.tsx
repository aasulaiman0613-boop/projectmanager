"use client";
import React, { useEffect, useState } from "react";

export function Toast({ message }: { message: string }) {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setShow(false), 3000);
    return () => clearTimeout(t);
  }, []);
  if (!show) return null;
  return <div className="fixed bottom-4 right-4 bg-slate-900 text-white px-4 py-2 rounded">{message}</div>;
}