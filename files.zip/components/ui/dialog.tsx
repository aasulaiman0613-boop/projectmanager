"use client";
import React from "react";
import { motion } from "framer-motion";

export function Dialog({ open, onClose, children }: { open: boolean; onClose: () => void; children: React.ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <motion.div initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="bg-white dark:bg-slate-800 p-4 rounded-md" onClick={(e) => e.stopPropagation()}>
        {children}
      </motion.div>
    </div>
  );
}