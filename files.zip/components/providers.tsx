"use client";
import { ReactNode, useEffect, useState } from "react";

/**
 * Simple providers wrapper for client features:
 * - theme class on <html>
 * - keyboard shortcuts
 */
export function Providers({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const stored = localStorage.getItem("plug_theme");
    if (stored === "dark") {
      setTheme("dark");
      document.documentElement.classList.add("dark");
    } else {
      setTheme("light");
      document.documentElement.classList.remove("dark");
    }
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "q" || e.key === "Q") {
        // open quick sale modal - we'll dispatch custom event
        window.dispatchEvent(new CustomEvent("pm:quick-sale"));
      } else if (e.key === "/") {
        const el = document.querySelector<HTMLInputElement>('input[data-pm-search="1"]');
        el?.focus();
        e.preventDefault();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return <>{children}</>;
}