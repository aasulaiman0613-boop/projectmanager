"use client";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { Button } from "./ui/button";

export default function Header() {
  const [search, setSearch] = useState("");

  useEffect(() => {
    // focus hotkey handler ("/") handled in Providers
    const onQuick = () => {
      // placeholder: show quick sale toast or modal
      alert("Quick Sale hotkey triggered (Q)");
    };
    window.addEventListener("pm:quick-sale", onQuick as EventListener);
    return () => window.removeEventListener("pm:quick-sale", onQuick as EventListener);
  }, []);

  return (
    <header className="border-b bg-white dark:bg-slate-800 dark:border-slate-700 px-6 py-3">
      <div className="container flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={clsx("text-lg font-medium")}>PlugManager</div>
          <input
            data-pm-search="1"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-1 rounded border dark:bg-slate-700 text-sm"
            placeholder="Search (/)"/>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="ghost" onClick={() => alert("Idle lock settings go here")}>Lock</Button>
        </div>
      </div>
    </header>
  );
}