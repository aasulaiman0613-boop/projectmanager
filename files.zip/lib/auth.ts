/**
 * Authentication helpers:
 * - setupInitialUser() seeds an owner user if missing (demo PIN 1234)
 * - login(pin) verifies bcrypt hash, derives master key and sets cookie
 * - logout() clears cookie and master key
 */
import { db, generateHexSalt } from "./db";
import { pbkdf2Key } from "./crypto";
import bcrypt from "bcryptjs";

const COOKIE_NAME = "plug_auth";

let inMemoryKey: CryptoKey | null = null;

function setAuthCookie() {
  // simple cookie (expires in 1 day)
  document.cookie = `${COOKIE_NAME}=1; path=/; max-age=${60 * 60 * 24}`;
}

function clearAuthCookie() {
  document.cookie = `${COOKIE_NAME}=; path=/; max-age=0`;
}

export async function setupInitialUser() {
  const users = await db.users.toArray();
  if (users.length > 0) return;

  // create demo owner with PIN 1234
  const pin = "1234";
  const salt = generateHexSalt(16);
  const hashed = bcrypt.hashSync(pin, 10);
  const owner = {
    id: "owner",
    name: "Owner",
    pinHash: hashed,
    pbkdf2Salt: salt,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  await db.users.put(owner);

  // demo seed: promoter, inventory, pack
  await db.promoters.put({
    id: "p1",
    name: "P1",
    createdAt: Date.now(),
    updatedAt: Date.now()
  });

  await db.inventoryBatches.put({
    id: "b1",
    itemName: "Sour Candy - Batch A",
    sku: "SA-A",
    units: 100,
    cost: 50,
    supplier: "Supplier A",
    createdAt: Date.now(),
    updatedAt: Date.now()
  });
  await db.inventoryBatches.put({
    id: "b2",
    itemName: "Sour Candy - Batch B",
    sku: "SA-B",
    units: 50,
    cost: 30,
    supplier: "Supplier B",
    createdAt: Date.now(),
    updatedAt: Date.now()
  });

  await db.packTemplates.put({
    id: "pack1",
    name: "3-sour-mini",
    units_required: 3,
    markupPercent: 100,
    rounding: 0.05,
    createdAt: Date.now(),
    updatedAt: Date.now()
  });

  // default settings
  await db.settings.put({
    id: "defaults",
    fifo: true,
    lockMinutes: 10,
    currency: "USD",
    globalSplit: { owner: 70, promoter: 30 },
    createdAt: Date.now(),
    updatedAt: Date.now()
  });
}

export async function login(pin: string) {
  const owner = await db.users.get("owner");
  if (!owner) return false;
  const ok = bcrypt.compareSync(pin, owner.pinHash);
  if (!ok) return false;
  // derive master key from pin + salt
  const key = await pbkdf2Key(pin, owner.pbkdf2Salt);
  inMemoryKey = key;
  db.setMasterKey(key);
  setAuthCookie();
  return true;
}

export function logout() {
  inMemoryKey = null;
  db.setMasterKey(null);
  clearAuthCookie();
}