import Dexie from "dexie";
import { pbkdf2Key, encryptJSON, decryptJSON, bytesToHex } from "./crypto";

export type AnyRecord = {
  id: string;
  createdAt: number;
  updatedAt: number;
  isArchived?: boolean;
  deletedAt?: number | null;
  lastEditedBy?: string;
  [k: string]: any;
};

class PlugDB extends Dexie {
  users!: Dexie.Table<AnyRecord, string>;
  inventoryBatches!: Dexie.Table<AnyRecord, string>;
  packTemplates!: Dexie.Table<AnyRecord, string>;
  sales!: Dexie.Table<AnyRecord, string>;
  saleBatchLinks!: Dexie.Table<AnyRecord, string>;
  promoters!: Dexie.Table<AnyRecord, string>;
  payouts!: Dexie.Table<AnyRecord, string>;
  settings!: Dexie.Table<AnyRecord, string>;
  audit!: Dexie.Table<AnyRecord, string>;
  profiles!: Dexie.Table<AnyRecord, string>;
  threads!: Dexie.Table<AnyRecord, string>;
  messages!: Dexie.Table<AnyRecord, string>;
  configurations!: Dexie.Table<AnyRecord, string>;

  private _masterKey: CryptoKey | null = null;

  constructor() {
    super("plugmanager-db");
    this.version(1).stores({
      users: "id,createdAt,updatedAt",
      inventoryBatches: "id,createdAt,updatedAt,itemName,sku",
      packTemplates: "id,createdAt,updatedAt,name",
      sales: "id,createdAt,updatedAt",
      saleBatchLinks: "id,createdAt,updatedAt",
      promoters: "id,createdAt,updatedAt,name",
      payouts: "id,createdAt,updatedAt",
      settings: "id",
      audit: "id,createdAt",
      profiles: "id,createdAt,updatedAt",
      threads: "id,createdAt,updatedAt",
      messages: "id,createdAt,updatedAt",
      configurations: "id"
    });
  }

  setMasterKey(key: CryptoKey | null) {
    this._masterKey = key;
  }

  // high-level helper: put record into a table with optional encryption
  async putEncrypted(tableName: string, record: AnyRecord) {
    const t = (this as any)[tableName] as Dexie.Table<any, string>;
    if (!t) throw new Error("Table not found: " + tableName);
    const now = Date.now();
    record.createdAt ||= now;
    record.updatedAt = now;

    if (this._masterKey) {
      const payload = { ...record };
      // keep id separate; encrypt full payload
      const ct = await encryptJSON(this._masterKey, payload);
      await t.put({ id: record.id, encrypted: ct, createdAt: record.createdAt, updatedAt: record.updatedAt });
      return;
    } else {
      await t.put(record);
      return;
    }
  }

  async getDecrypted(tableName: string, id: string) {
    const t = (this as any)[tableName] as Dexie.Table<any, string>;
    const row = await t.get(id);
    if (!row) return null;
    if (row.encrypted && this._masterKey) {
      const obj = await decryptJSON(this._masterKey, row.encrypted);
      return obj;
    }
    return row;
  }

  async allDecrypted(tableName: string) {
    const t = (this as any)[tableName] as Dexie.Table<any, string>;
    const all = await t.toArray();
    if (this._masterKey) {
      const results = [];
      for (const r of all) {
        if (r.encrypted) {
          try {
            const o = await decryptJSON(this._masterKey, r.encrypted);
            results.push(o);
          } catch (e) {
            // cannot decrypt; push placeholder
            results.push({ id: r.id, _encrypted: true });
          }
        } else {
          results.push(r);
        }
      }
      return results;
    } else {
      return all;
    }
  }
}

export const db = new PlugDB();

// helper to create hex salt
export function generateHexSalt(len = 16) {
  const arr = crypto.getRandomValues(new Uint8Array(len));
  return bytesToHex(arr);
}