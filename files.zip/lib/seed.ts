import { db } from "./db";

/**
 * Data seeding utilities (re-usable)
 */

export async function ensureSeeded() {
  const users = await db.users.toArray();
  if (users.length === 0) {
    // setupInitialUser in auth handles seeding
    return;
  }
}