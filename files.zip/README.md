```markdown
# PlugManager Web

PlugManager Web — private resale-management dashboard (local-first).

This project is a starter/demo implementation built with:
- Next.js 15 (App Router)
- TypeScript (strict)
- Tailwind CSS
- Dexie (IndexedDB) for local storage
- AES-GCM encryption (Web Crypto API)
- bcryptjs for PIN hashing
- Framer Motion for transitions
- Minimal shadcn-like UI components (local components)
- No external paid services — fully local and can be deployed to Vercel

Features implemented in this scaffold:
- App router with a left sidebar and responsive dashboard shell
- Login with PIN (default demo PIN: `1234`) and cookie-based route protection
- Master key derived from PIN (PBKDF2); optional encryption for stored records when logged in
- Dexie DB setup with stores and helper wrappers
- Demo seed data: owner user, promoter P1, two inventory batches (Sour Candy), and pack "3-sour-mini"
- Idle lock hotkey and a basic lock mechanism
- Basic pages for Inventory, Packs, Sales, Promoters, Drops, Messages, Reports, Audit, Settings
- Keyboard shortcuts: Q = Quick Sale (fires a demo action), / = focus search input
- CSV/JSON export placeholders and confirmation modals (UI ready)
- Utilities: clsx, tailwind-merge included

Important notes:
- This is a local-first demo. Sensitive data stays in the browser (IndexedDB).
- Encryption is applied when a master key is set (after login). Data is still accessible on the client.
- For multi-profile features, you can extend the `profiles` store in DB and switch salts/master keys per profile.

Getting started (local):

1. Install dependencies
   npm install

2. Run the dev server
   npm run dev

3. Open your browser:
   http://localhost:3000
   Login PIN (demo): 1234

Build for production:
- npm run build
- npm run start

Deploy:
- This project is compatible with Vercel. On Vercel, build command should be:
  npm run build
  and the output path is handled by Next.js automatically.

Files of interest:
- app/ — Next.js app routes and pages
- components/ — layout, sidebar, header, UI primitives
- lib/db.ts — Dexie DB initialization and helper functions
- lib/crypto.ts — AES-GCM helpers (derive key, encrypt, decrypt)
- lib/auth.ts — simple PIN-based auth and cookie session
- middleware.ts — protects routes by checking for a session cookie

Security & further steps:
- For higher security, generate and persist stronger salts, tie cookies to derived tokens, and use HttpOnly cookies set by a server process.
- Consider adding an export/import flow that requires the PIN to decrypt/restore data.
- For shared devices, use more secure cookie/session handling or a small server-side auth.

If you want, I can:
- Add a full export/import encrypted JSON UI
- Implement the full CRUD operations UI (inline edit, bulk select) across modules
- Improve the encryption strategy (client-side envelope encryption)
- Add tests & typed TypeScript models for each store

```