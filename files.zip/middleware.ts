import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Simple middleware that protects app routes by checking for a small cookie.
 * - If cookie "plug_auth" is not present, redirect to /login
 *
 * Note: Full security is local-only; cookie is used to gate UI.
 */

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // public routes
  if (pathname.startsWith("/_next") || pathname.startsWith("/api") || pathname.startsWith("/login") || pathname.startsWith("/favicon.ico") || pathname.startsWith("/static")) {
    return NextResponse.next();
  }

  const cookie = req.cookies.get("plug_auth");
  if (!cookie) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"]
};